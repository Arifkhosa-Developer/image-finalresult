﻿using System.ComponentModel.DataAnnotations;
namespace SetupService.Model.MarketingProject
{
    public class MFRProjectType
    {
        [Key]
        public int ProjectTypeID { get; set; }
        public string ProjectTypeCode { get; set; }
        public string ProjectTypeName { get; set; }
        public int? DonationTypeID { get; set; }
        public bool IsActive { get; set; }
        public int BusinessID { get; set; }
        public int? InsertedBy { get; set; }
        public DateTime? InsertedDate { get; set; }
        public string InsertedUIP { get; set; }
        public int? UpdatedBy { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public string UpdatedUIP { get; set; }
    }
}
