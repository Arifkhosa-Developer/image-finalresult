﻿using AutoMapper;
using CommonService.Utility;
using SetupService.Model.MarketingProject;
using SetupService.Service.MarketingProject.MfrTeam.Request;

namespace SetupService.Utility.MappingConfigurations.Setup
{
    public class MfrTeamProfiler : Profile
    {
        public MfrTeamProfiler()
        {
            CreateMap<SaveMfrTeamRequest, MFRTeam>()
            .ForMember(dest => dest.MfrTeamEmployee, opt => opt.MapFrom(x => x.MfrTeamEmployee))
            .ForMember(dest => dest.MfrTeamDonor, opt => opt.MapFrom(x => x.MfrTeamDonor))
            .ForMember(dest => dest.MfrTeamArea, opt => opt.MapFrom(x => x.MfrTeamArea))
            .ForMember(dest => dest.MfrTeamSubArea, opt => opt.MapFrom(x => x.MfrTeamSubArea))

           .AfterMap((src, dst) =>
           {
               if (dst.TeamID > 0)
               {
                   dst.UpdatedDate = DateTime.Now;
                   dst.UpdatedUIP = NetHelper.Ip;
               }
               else
               {
                   dst.InsertedDate = DateTime.Now;
                   dst.InsertedUIP = NetHelper.Ip;
               }
           });
            CreateMap<TeamEmployeeRequest, MfrTeamEmployee>();
            CreateMap<DonorRequest, MfrTeamDonor>();
            CreateMap<TeamAreaRequest, MFRTeamArea>();
            CreateMap<TeamSubAreaRequest, MFRTeamSubArea>();

        }
    }
}
