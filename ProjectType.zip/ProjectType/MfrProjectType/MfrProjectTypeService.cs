﻿using System.Data;
using System.Text;
using CommonService.Utility;
using Dapper;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Distributed;
using Newtonsoft.Json;
using SetupService.Model.Contexts;
using SetupService.Model.MarketingProject;
using SetupService.Service.MarketingProject.MfrProjectType.Response;
using SetupService.Service.MarketingProject.MfrRegion.Response;
using SetupService.Utility;


namespace SetupService.Service.MarketingProject.MfrProjectType
{
    public class MfrProjectTypeService : BaseResponse, IMfrProjectTypeService
    {
        private readonly DatabaseContext _dbContext;
        private readonly DapperContext _dbDapperContext;
        private readonly IDistributedCache _distributedCache;
        public MfrProjectTypeService(DatabaseContext dbContext, DapperContext dbDapperContext, IDistributedCache distributedCache)
        {
            _dbContext = dbContext;
            _dbDapperContext = dbDapperContext;
            _distributedCache = distributedCache;
           ;
        }

        public async Task<bool> CheckExistsProjectTypeName(string projectTypeName, int? businessId, int projectTypeID)
        {
            var result= await _dbContext.MfrProjectType.Where(s => s.ProjectTypeName == projectTypeName && s.BusinessID == businessId && s.ProjectTypeID != projectTypeID).AnyAsync();
            return result ? true : false;
        }

        public async Task<bool> SaveProjectType(MFRProjectType request, string userID)
        {
            if (request.ProjectTypeID == 0)
            {
                request.InsertedBy = Convert.ToInt32(userID);
               // request.InsertedDate = DateTime.Now;
                await _dbContext.MfrProjectType.AddAsync(request);
            }
            else
            {
                request.UpdatedBy = Convert.ToInt32(userID);
              //  request.UpdatedDate = DateTime.Now;
                _dbContext.Entry(request).Property(x => x.ProjectTypeName).IsModified = true;
                _dbContext.Entry(request).Property(x => x.ProjectTypeCode).IsModified = true;
                _dbContext.Entry(request).Property(x => x.DonationTypeID).IsModified = true;
                _dbContext.Entry(request).Property(x => x.IsActive).IsModified = true;
                _dbContext.Entry(request).Property(x => x.BusinessID).IsModified = true;
                _dbContext.Entry(request).Property(x => x.UpdatedDate).IsModified = true;
                _dbContext.Entry(request).Property(x => x.UpdatedBy).IsModified = true;           
                _dbContext.Entry(request).Property(x => x.UpdatedUIP).IsModified = true;
            }

            await _dbContext.SaveChangesAsync();
            request.ProjectTypeCode = request.ProjectTypeID.ToString("0000");
            _dbContext.Entry(request).Property(x=>x.ProjectTypeCode).IsModified= true;
            await _dbContext.SaveChangesAsync();
            await GetProjectTypeByActiveListCache();
            return true;
        }
        //ProjectTypeServices By ActiveList
        public async Task<List<GetProjectTypeByActiveListResponse>> GetProjectTypeByActiveList(string businessId)
        {
            List<GetProjectTypeByActiveListResponse> list = new List<GetProjectTypeByActiveListResponse>();
            var jsonData = await _distributedCache.GetStringAsync("MfrProjectTypeByActiveList");
            int BusinessID = Decrypt<int>(businessId);
            if (string.IsNullOrEmpty(businessId) || jsonData == "[]")
            {
                list = await GetProjectTypeByActiveListCache();
                return list.Where(x => x.BusinessID == BusinessID).ToList();
            }

            return JsonConvert.DeserializeObject<List<GetProjectTypeByActiveListResponse>>(jsonData).Where(x => x.BusinessID == BusinessID).ToList();


        }
        private async Task<List<GetProjectTypeByActiveListResponse>> GetProjectTypeByActiveListCache()
        {
            List<GetProjectTypeByActiveListResponse> list = new List<GetProjectTypeByActiveListResponse>();
            using (var con = _dbDapperContext.CreateConnection())
            {
                DynamicParameters para1 = new DynamicParameters();
                var result = await con.QueryAsync<GetProjectTypeByActiveListResponse>("USP_MfrProjectType_GetProjectTypeByActiveList", commandType: CommandType.StoredProcedure);
                list = result.ToList();
            }
            await _distributedCache.SetStringAsync("MfrProjectTypeByActiveList", JsonConvert.SerializeObject(list));
            return list;
        }


        
        public async Task<List<GetProjectTypeByActiveListResponse>> GetProjectTypeByDonationTypeId(string Donationtypeid, string businessID)
        {
            return await _dbContext.MfrProjectType.AsNoTracking()
            .Where(s => s.BusinessID == Decrypt<int>(businessID) && s.DonationTypeID == Decrypt<int>(Donationtypeid) && s.IsActive == true)
            .Select(br => new GetProjectTypeByActiveListResponse
            {
                ProjectTypeID = br.ProjectTypeID,
                ProjectTypeName = br.ProjectTypeName
            })
             .ToListAsync();
        }

        public async Task<List<GetProjectTypeBySearchListResponse>> GetProjectTypeBySearchList(GenericSetupPageList request)
        {
            StringBuilder Cwhere = new StringBuilder();
            using (var con = _dbDapperContext.CreateConnection())
            {
                Cwhere.Append(" and pt.BusinessID=" + Decrypt<int>(request.BusinessID));
                if (request.SearchParameters != null)
                {
                    if (!string.IsNullOrEmpty(request.SearchParameters.VCode))
                    {
                        Cwhere.Append(" and pt.ProjectTypeCode like '%" + request.SearchParameters.VCode + "%'");
                    }
                    if (!string.IsNullOrEmpty(request.SearchParameters.VName))
                    {
                        Cwhere.Append(" and pt.ProjectTypeName like '%" + request.SearchParameters.VName + "%'");
                    }
                    if (!string.IsNullOrEmpty(request.SearchParameters.IsActive))
                    {
                        Cwhere.Append(" and pt.IsActive =" + (Convert.ToBoolean(request.SearchParameters.IsActive) ? 1 : 0));
                    }

                }
                DynamicParameters para = new DynamicParameters();
                para.Add("@PageNo", request.PageNo);
                para.Add("@PageSize", request.PageSize);
                para.Add("@SortOrder", request.SortOrder);
                para.Add("@Cwhere", Cwhere.ToString());
                var result = await con.QueryAsync<GetProjectTypeBySearchListResponse>("USP_MfrProjectType_GetProjectTypeBySearchList", para, commandType: CommandType.StoredProcedure);
                return result.ToList();
            }
        }
    }
    }
