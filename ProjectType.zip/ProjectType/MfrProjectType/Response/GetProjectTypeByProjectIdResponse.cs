﻿using CommonService.Utility;
using System.Text.Json.Serialization;
namespace SetupService.Service.MarketingProject.MfrProjectType.Response
{
    public class GetProjectTypeByProjectIdResponse: BaseResponse
    {
        public string ProjectTypeIDHash { get; set; }

        [JsonIgnore]
        public int ProjectTypeID { get { return Decrypt<int>(ProjectTypeIDHash); } set { ProjectTypeIDHash = Encrypt(value); } }

        public string ProjectTypeCode { get; set; }
        public string ProjectTypeName { get; set; }

        public string DonationTypeIDHash { get; set; }

        [JsonIgnore]
        public int? DonationTypeID { get {return Decrypt<int>(DonationTypeIDHash); } set { DonationTypeIDHash = Encrypt(value); } }

        public bool? IsActive { get; set; }

        public string BusinessIDHash { get; set; }

        [JsonIgnore]
        public int? BusinessID  { get { return Decrypt<int>(BusinessIDHash); } set { BusinessIDHash = Encrypt(value); } }

        public int? InsertedBy { get; set; }
        public DateTime? InsertedDate { get; set; }
        public string InsertedUIP { get; set; }
        public int? UpdatedBy { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public string UpdatedUIP { get; set; }
    }
}
