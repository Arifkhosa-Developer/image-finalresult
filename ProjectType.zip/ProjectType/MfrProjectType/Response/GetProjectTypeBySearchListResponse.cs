﻿using CommonService.Utility;
using System.Text.Json.Serialization;
namespace SetupService.Service.MarketingProject.MfrProjectType.Response
{
    public class GetProjectTypeBySearchListResponse: BaseResponse
    {
        public long? RowNum { get; set; }

        public string ProjectTypeIDHash { get; set; }

        [JsonIgnore]
        public int ProjectTypeID {  get { return Decrypt<int>(ProjectTypeIDHash); }  set { ProjectTypeIDHash = Encrypt(value); }  }

        public string ProjectTypeCode { get; set; }
        public string ProjectTypeName { get; set; }

        public string DonationTypeName { get; set; } // Optional: if joined from a DonationType table
        public bool? IsActive { get; set; }

        public int? Total { get; set; } // Used for pagination, 
    }
}
