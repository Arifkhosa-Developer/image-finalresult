﻿using CommonService.Utility;
using System.Text.Json.Serialization;
namespace SetupService.Service.MarketingProject.MfrProjectType.Response
{
    public class GetProjectTypeByActiveListResponse: BaseResponse
    {
        public string ProjectTypeIDHash { get; set; }

        [JsonIgnore]
        public int ProjectTypeID { get { return Decrypt<int>(ProjectTypeIDHash); } set { ProjectTypeIDHash = Encrypt(value); } }
   
        public string ProjectTypeName { get; set; }

        public string BusinessIDHash { get; set; }

        [JsonIgnore]
        public int BusinessID { get { return Decrypt<int>(BusinessIDHash); } set { BusinessIDHash = Encrypt(value); } }
    }
}
