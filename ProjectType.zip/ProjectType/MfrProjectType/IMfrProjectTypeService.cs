﻿using SetupService.Model.MarketingProject;
using SetupService.Service.MarketingProject.MfrProjectType.Response;
using SetupService.Service.MarketingProject.MfrRegion.Response;
using SetupService.Utility;


namespace SetupService.Service.MarketingProject.MfrProjectType
{
    public interface IMfrProjectTypeService
    {
        Task<bool> CheckExistsProjectTypeName(string projectTypeName, int? businessId, int projectTypeID);
        Task<bool> SaveProjectType(MFRProjectType request, string userID);
        Task<List<GetProjectTypeByActiveListResponse>> GetProjectTypeByActiveList(string businessId);
        Task<List<GetProjectTypeByActiveListResponse>> GetProjectTypeByDonationTypeId(string Donationtypeid, string businessId);
        Task<List<GetProjectTypeBySearchListResponse>> GetProjectTypeBySearchList(GenericSetupPageList request);
    }
}